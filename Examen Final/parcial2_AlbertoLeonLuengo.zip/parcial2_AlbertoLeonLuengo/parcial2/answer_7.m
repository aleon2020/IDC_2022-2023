syms l1 r2 x1(t) x2(t) d_x1(t) d_x2(t)

% Matriz jacobiana (x)
J = [-sin(x1+(pi/2))*(r2+x2)-l1*sin(x1),cos(x1+(pi/2));
     cos(x1+(pi/2))*(r2+x2)+l1*cos(x1),sin(x1+(pi/2))];

% Derivada de la matriz jacobiana (x)
dotJ = diff(J,t)

% Simplificación
simplified_dotJ = subs(dotJ,diff(x2(t),t),d_x2(t));
final_dotJ = subs(simplified_dotJ,diff(x1(t),t),d_x1(t))