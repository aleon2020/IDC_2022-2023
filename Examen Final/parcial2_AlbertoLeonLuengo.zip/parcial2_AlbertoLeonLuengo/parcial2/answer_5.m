syms l1 r1 q1(t) q2(t) d_q1(t) d_q2(t)

% Coordinates of point p(q)
px = l1*cos(q1)+(q2+r2)*cos(q1+(pi/2));
py = l1*sin(q1)+(q2+r2)*sin(q1+(pi/2));

P = [px;
     py];

v1 = diff(P,t);

v2 = subs(v1,diff(q1(t)),d_q1);
d_P = subs(v2,diff(q2(t)),d_q2)