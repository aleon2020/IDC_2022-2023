syms l1 r2 px(t) py(t) d_px(t) d_py(t)

% Coordenadas del punto p(q) igualadas a q
q1 = 2*atan((py+(-l1^2+px^2+py^2)^0.5)/(l1+px));
q2 = -r2 + (-l1^2+px^2+py^2)^0.5;

% Derivada de las ecuaciones anteriores
% respecto del tiempo
d_q1 = diff(q1,t);
d_q2 = diff(q2,t);

% Sustitución por valores más legibles
d_q1_1 = subs(d_q1,diff(p1,t),d_p1);
d_q1_Final = subs(d_q1_1,diff(p2,t),d_p2);
d_q2_Final = subs(d_q2,diff(p2,t),d_p2);
d_q = [d_q1_Final;d_q2_Final]