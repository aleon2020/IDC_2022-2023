close all;
clear;
clc;

figure
hold
grid

xmin = 0;
xmax = 20;
ymin = 0;
ymax = 20;

axis([xmin xmax ymin ymax]);
axis('square');