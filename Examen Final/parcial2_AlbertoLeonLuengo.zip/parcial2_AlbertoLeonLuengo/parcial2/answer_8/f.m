function xdot = f(x,u)
    % Parámetros
    l1 = 1;
    l2 = 1;
    m1 = 1;
    m2 = 1;
    I1 = 1;
    I2 = 1;
    d1 = l1/2;
    d2 = l2/2;
    r2 = l2/2;
    g = 9.81;

    % Variables
    q1 = x(1);
    q2 = x(2);
    d_q1 = x(3);
    d_q2 = x(4);
    u1 = u(1);
    u2 = u(2);

    % Matrices (q)
    B = [I1+m1*d1^2+I2+m2*l1^2+m2*q2^2,m2*l1;
         m2*l1,m2];
    C = [2*m2*q2*d_q1*d_q2;
         -m2*q2*d_q1^2];
    N = [(m1*d1+m2*l1)*g*cos(q1)-m2*g*q2*sin(q1);
         m2*g*cos(q1)];

    % Representación del espacio de estados
    dd_q = inv(B)*(-C + u - N);
    xdot = [d_q1;d_q2;dd_q(1);dd_q(2)];
end