function draw(x,pd)
    % Parámetros
    l1 = 1;
    l2 = 1;
    m1 = 1;
    m2 = 1;
    I1 = 1;
    I2 = 1;
    d1 = l1/2;
    d2 = l2/2;
    r2 = l2/2;
    g = 9.81;
    
    % Dibujo
    clf()
    hold on 
    axis square
    axis([-2,2,-2,2])

    q1 = x(1);
    q2 = x(2);

    p1 = l1*cos(q1) + (q2+r2)*cos(q1+(pi/2));
    p2 = l1*sin(q1) + (q2+r2)*sin(q1+(pi/2));
    
    % NO ME HA DADO TIEMPO A PONER LAS MEDIDAS
    plot([,],[,],'r','LineWidth',1)
    plot([,],[,],'r','LineWidth',1)

    drawnow;
end