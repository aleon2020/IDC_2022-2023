init;

% Estado inicial
x = [0;0;0;0];
u = [0;0];
y = [0;0];

% Velocidad lineal
w = 0.1;

% Parámetros
l1 = 1;
l2 = 1;
m1 = 1;
m2 = 1;
I1 = 1;
I2 = 1;
d1 = l1/2;
d2 = l2/2;
r2 = l2/2;
g = 9.81;

% Contadores
frame_counter = 0;
dt = 0.01;
t = 0;

for t = 0:dt:100
    q1 = x(1);
    q2 = x(2);
    d_q1 = x(3);
    d_q2 = x(4);
    u1 = u(1);
    u2 = u(2);

    % Coordenadas del punto p (q)
    p = [l1*cos(q1) + (q2+r2)*cos(q1+(pi/2));
         l1*sin(q1) + (q2+r2)*sin(q1+(pi/2))];

    % Matriz jacobiana (q)
    J = [-sin(q1+(pi/2))*(r2+q2)-l1*sin(q1),cos(q1+(pi/2));
         cos(q1+(pi/2))*(r2+q2)+l1*cos(q1),sin(q1+(pi/2))];

    % Controlador PD
    Kp = [50,0;
          0,50];
    Kd = [10,0;
          0,10];

    % FEEDBACK LINEARIZATION METHOD
    % Derivada de la matriz jacobiana
    dotJ = [-sin((pi/2)+q1)*d_q2-cos((pi/2)+q1)*d_q1*(r2+q2)-l1*cos(q1)*d_q1,-sin((pi/2)+q1)*d_q1;
            cos((pi/2)+q1)*d_q2-sin((pi/2)+q1)*d_q1*(r2+q2)-l1*sin(q1)*d_q1,-sin((pi/2)+q1)*d_q1];
    % Posición deseada
    func = rem(int32(w*t),2);
    if func == 0
        % Posición A
        pd = [0.4;1.2];
    else
        % Posición B
        pd = [0.3;1.3];
    end
    pd_d = [0;0];
    pd_dd = [0;0];

    v = inv(J)*(pd_dd + Kd * (pd_d - J * [x(3);x(4)]) + Kp * (pd - p) - dotJ*[x(3);x(4)]);

    % Matrices (q)
    B = [I1+m1*d1^2+I2+m2*l1^2+m2*q2^2,m2*l1;
         m2*l1,m2];
    C = [2*m2*q2*d_q1*d_q2;
         -m2*q2*d_q1^2];
    N = [(m1*d1+m2*l1)*g*cos(q1)-m2*g*q2*sin(q1);
         m2*g*cos(q1)];

    u = B*v + C + N;
    % --------------------------------

    % Euler
    x = x + f(x,u) * dt;

    % Runge-Kutta
    x = x + dt*(0.25*f(x,u) + 0.75*(f(x+dt*(2/3)*f(x,u),u)));

    frame_counter = frame_counter + 1;

    % Frame sampling
    if frame_counter == 10
        plot(t,x(1),'k--.',t,x(2),'r--.',t,u(1),'g--.',t,u(2),'m--.')
        legend('q1','q2','xp','yp')
        % draw(x,pd)
        pause(dt)
        frame_counter = 0;
    end
end