syms l1 r2 q1 q2 d_q1 d_q2 dd_q1 dd_q2 p1 p2

% Coordinates of point p(q)
px = l1*cos(q1) + (q2+r2)*cos(q1+(pi/2));
py = l1*sin(q1) + (q2+r2)*sin(q1+(pi/2));

q = [px;py];

P_old = [p1;p2];

r1 = subs(P_old,p1,px);
P = subs(r1,p2,py)