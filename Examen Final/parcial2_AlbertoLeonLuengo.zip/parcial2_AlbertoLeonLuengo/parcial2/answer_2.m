close all;
clear;
clc;

syms l1 l2 m1 m2 I1 I2 d1 d2 r2 g u1 u2 q1 q2 d_q1 d_q2 dd_q1 dd_q2
syms x1 x2 x3 x4  

% Lagrange equations
eq1 = (I1+m1*d1^2+I2+m2*l1^2+m2*q2^2)*dd_q1+(m2*l1)*dd_q2+2*m2*q2*d_q1*d_q2 + (m1*d1+m2*l1)*g*cos(q1) - m2*g*q2*sin(q1);
eq2 = (m2*l1)*dd_q1 + m2*dd_q2 - m2*q2*d_q1^2 + m2*g*cos(q1);

S = solve(eq1==u1, eq2==u2, dd_q1, dd_q2, 'Real', true);
xdot = [x3; x4; S.dd_q1; S.dd_q2];

% State space representation
xdot = subs(xdot, [q1, q2, dd_q1, dd_q2], [x1, x2, x3, x4])