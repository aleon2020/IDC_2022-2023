syms l1 r2 px(t) py(t) d_px(t) d_py(t)

% Coordenadas del punto p(q) igualadas a q
q1_1 = 2*atan((py+(-l1^2+px^2+py^2)^0.5)/(l1+px));
q1_2 = 2*atan((py-(-l1^2+px^2+py^2)^0.5)/(l1+px));
q2_1 = -r2 + (-l1^2+px^2+py^2)^0.5;
q2_2 = -r2 + (-l1^2+px^2+py^2)^0.5;
q_1 = [q1_1; q2_1]
q_2 = [q1_2; q2_2]