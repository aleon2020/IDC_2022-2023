close all; 
clear all; 
clc;
figure
hold
xmin=-10;
xmax=100;
ymin=-10;
ymax=100;
axis([xmin xmax ymin ymax]); 
axis ('square');