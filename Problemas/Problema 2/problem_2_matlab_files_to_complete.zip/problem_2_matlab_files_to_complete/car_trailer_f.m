% Adapted from https://www.ensta-bretagne.fr/jaulin/

function  xdot  = f(x,u)
% state x = (x,y,theta,v,delta)
% control u=(u1 u2)
L=3;

px=x(1);
py=x(2);
theta=x(3);
%%%%%

%%%%%
v=x(4);
delta=x(5);

xdot=[v*cos(delta)*cos(theta); v*cos(delta)*sin(theta); v*sin(delta)/L; u(1); u(2)];
end

