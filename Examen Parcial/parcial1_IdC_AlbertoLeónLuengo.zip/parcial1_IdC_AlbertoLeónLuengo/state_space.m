close all;
clear all;
clc;
syms m1 m2 I1 I2 L1 Lc1 g ddq1 ddq2 u q1 q2
f1 = (m1*Lc1^2+m2*L1^2+I1+I2)*ddq1 + I2*ddq2 - (m1*Lc1+m2*L1)*g*sin(q1) == 0;
f2 = I2*ddq1 + I2*ddq2 == u;
result_2 = solve([f1 f2],[ddq1 ddq2],ReturnConditions=true,IgnoreAnalyticConstraints=true)