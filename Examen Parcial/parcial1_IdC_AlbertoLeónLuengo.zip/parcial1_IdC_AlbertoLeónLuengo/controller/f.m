function xdot = f(x,u)
    m1 = 200;
    m2 = 50;
    I1 = 25;
    I2 = 5;
    L1 = 1;
    Lc1 = 0.5;
    g = 9.81;
    x1 = x(1);
    x2 = x(2);
    x3 = x(3);
    x4 = x(4);
    dq1 = x3;
    dq2 = x4;
    ddq1 = (L1*m2*g*sin(x1)-u+Lc1*g*m1*sin(x1))/(m2*L1^2+m1*Lc1^2+I1);
    ddq2 = (m2*u*L1^2-I2*g*m2*sin(x1)*L1+m1*u*Lc1^2-I2*g*m1*sin(x1)*Lc1+I1*u+I2*u)/(I2*(m2*L1^2+m1*Lc1^2+I1));
    xdot = [dq1;dq2;ddq1;ddq2];
end