close all;
clear all;
clc;
figure('Position',[2000 1000 750 750]);
grid
hold
xmin = -10;
xmax = 10;
ymin = -10;
ymax = 10;
axis([xmin xmax ymin ymax]);
axis('square')