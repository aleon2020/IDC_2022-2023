function draw(x)
    clc()
    clf()
    hold on 
    axis square
    axis([-15,15,-15,15])
    q1 = x(1);
    q2 = x(2);
    dibujo = [];
    matriz_rotacion = [cos(),-sen(),0;
                       sen(),cos(),0;
                       0,0,1];
    matriz_traslacion = [1,0,q1;
                         0,1,q2;
                         0 0 1];
    aplicacion = matriz_rotacion * matriz_traslacion;
    resultado = aplicacion * dibujo;
    plot(resultado(1,:),resultado(2,:),'black','Linewidth',1)
end