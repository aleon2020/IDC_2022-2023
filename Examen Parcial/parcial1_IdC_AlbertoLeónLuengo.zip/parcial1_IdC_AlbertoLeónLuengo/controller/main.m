init;
% Parámetros
m1 = 200;
m2 = 50;
I1 = 25;
I2 = 5;
L1 = 1;
Lc1 = 0.5;
g = 9.81;
% Estado inicial
x = [0.261799;0;0;0];
% Puntos de equilibrio
x_equilibrio = [0;0;0;0];
w_equilibrio = [0;0];
u_equilibrio = [0;0];
t = 0;
A = [0 0 1 0;
     0 0 0 1;
     (L1*g*m2+Lc1*g*m1)/(m2*L1^2+m1*Lc1^2+I1) 0 0 0;
     -((I2*L1*g*m2+I2*Lc1*g*m1)/(I2*(m2*L1^2+m1*Lc1^2+I1))) 0 0 0];
B = [0;
     0;
     -((1)/(m2*L1^2+m1*Lc1^2+I1));
     (m2*L1^2+m1*Lc1^2+I1+I2)/(I2*(m2*L1^2+m1*Lc1^2+I1))];
% LQR method
Q = [1 0 0 0;
     0 1 0 0;
     0 0 0 0;
     0 0 0 0];
R = 2;
K = lqr(A,B,Q,R);
E = [1 0 0 0];
H = -inv(E*inv(A-B*K)*B);
frame_counter = 0;
dt = 0.01;
for t = 0:dt:10
    % Estado final
    w = [0;0];
    u = u_equilibrio - K*x + H*w;
    % Euler
    x = x + f(x,u)*dt;
    % Runge-Kutta
    % x = x + dt*(0.25+f(x,u)+0.75*(f(x+dt*2/3*f(x,u),u)));
    pause(dt);
    frame_counter = frame_counter + 1;
    if frame_counter == 15
        % draw(x);
        plot(t,x(1),'k--.',t,x(2),'r--.',t,u,'g--.')
        legend('q1(t)','q2(t)','u(t)')
        frame_counter = 0;
    end
end