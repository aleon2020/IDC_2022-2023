close all;
clear all;
clc;
syms x1 x2 x3 x4 u m1 m2 I1 I2 L1 Lc1 g
m1 = 200;
m2 = 50;
I1 = 25;
I2 = 5;
L1 = 1;
Lc1 = 0.5;
g = 9.81;
A = [0 0 1 0;
     0 0 0 1;
     (L1*g*m2+Lc1*g*m1)/(m2*L1^2+m1*Lc1^2+I1) 0 0 0;
     -((I2*L1*g*m2+I2*Lc1*g*m1)/(I2*(m2*L1^2+m1*Lc1^2+I1))) 0 0 0];
B = [0;
     0;
     -((1)/(m2*L1^2+m1*Lc1^2+I1));
     (m2*L1^2+m1*Lc1^2+I1+I2)/(I2*(m2*L1^2+m1*Lc1^2+I1))];
C_x1 = [1 0 0 0];
C_x2 = [0 1 0 0];
% Caso 1: y = x1
Obs_x1 = obsv(A,C_x1)
unobs_x1 = length(A) - rank(Obs_x1)
% Caso 2: y = x2
Obs_x2 = obsv(A,C_x2)
unobs_x2 = length(A) - rank(Obs_x2)