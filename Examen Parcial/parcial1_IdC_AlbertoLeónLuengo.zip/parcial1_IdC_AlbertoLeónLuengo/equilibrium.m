close all;
clear all;
clc;
syms x1 x2 x3 x4 u m1 m2 I1 I2 L1 Lc1 g q1 q2
f1 = x3 == 0;
f2 = x4 == 0;
f3 = (L1*m2*g*sin(x1)-u+Lc1*g*m1*sin(x1))/(m2*L1^2+m1*Lc1^2+I1) == 0;
f4 = (m2*u*L1^2-I2*g*m2*sin(x1)*L1+m1*u*Lc1^2-I2*g*m1*sin(x1)*Lc1+I1*u+I2*u)/(I2*(m2*L1^2+m1*Lc1^2+I1)) == 0;
result = solve([f1,f2,f3,f4],[x1,x2,x3,x4,u],ReturnConditions=true,IgnoreAnalyticConstraints=true)