close all; 
clear all; 
clc;
figure
hold
grid
xmin=-1;
xmax=2;
ymin=-1;
ymax=2;
axis([xmin xmax ymin ymax]); 
axis ('square');