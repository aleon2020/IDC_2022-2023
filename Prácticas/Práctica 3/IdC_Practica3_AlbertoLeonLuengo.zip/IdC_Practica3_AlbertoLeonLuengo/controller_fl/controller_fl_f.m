function  xdot  = controller_fl_f(x,u)
    % Parameters
    I1 = 1;
    I2 = 1;
    m2 = 1;
    g = 9.81;

    % State variables
    q1 = x(1);
    q2 = x(2);
    d_q1 = x(3);
    d_q2 = x(4);
    u1 = u(1);
    u2 = u(2);

    % Matrixes
    B = [I1 + I2 + m2*(q2^2), 0;
         0, m2];
    C = [2*m2*q2*d_q1*d_q2;
         -m2*q2*(d_q1^2)];
    N = m2*g*[q2*cos(q1); sin(q1)];
    dd_q = inv(B)*(-C + u - N);

    % State space representation calculated in b
    xdot=[d_q1; d_q2; dd_q(1); dd_q(2)];
end