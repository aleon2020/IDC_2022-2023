syms d2 x1(t) x2(t)
J = [-sin(x1)*(d2+x2) cos(x1);
     cos(x1)*(d2+x2) sin(x1)];
Jdot = diff(J,t)