function controller_jt_draw(x,pd)
    % Parameters
    d2 = 0.5;
    g = 9.81;
    c = [0.5,0.5];
    r = 0.25;
    
    % Drawing
    clf();
    hold on
    axis square
    axis([-0.5,1,-0.5,1])
    x1 = x(1);
    x2 = x(2);
    arm = [0,d2 + x2;
           0,0;
           1,1];
    rotation_matrix = [cos(x1), -sin(x1), 0;
            sin(x1), cos(x1), 0;
            0,0,1];
    result = rotation_matrix*arm;
    plot(pd(1),pd(2),'+ k');
    plot(0,0,'o k');
    circle = nsidedpoly(1000,"Center", c, "Radius", r);
    plot(circle, "FaceColor", "w", "FaceAlpha",0);
    plot(result(1,:),result(2,:),"black", "LineWidth",1);
end