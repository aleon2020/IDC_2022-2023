controller_jt_init;

% Initial state
x = [0;0;0;0]; 
u = [0;0];
y = [0;0];
w = 0.25;

% Parameters
I1 = 1;
I2 = 1;
m2 = 1;
l2 = 1;
d2 = 0.5;
g = 9.81;

% Center and radius of the circle
r = 0.25;
c  = [0.5, 0.5];

frame_counter=0;
dt=0.01;
t=0;
 
for t=0:dt:30
    % State variables
    q1 = x(1);
    q2 = x(2);
    d_q1 = x(3);
    d_q2 = x(4);
    u1 = u(1);
    u2 = u(2);

    % P coordinates calculated in c
    p = [(q2 + d2)*cos(q1); 
         (q2 + d2)*sin(q1)];

    % Jacobian matrix calculated in d
    J = [-(d2 + q2)*sin(q1), cos(q1);
          (d2 + q2)*cos(q1), sin(q1)];

    % Derivative of the Jacobian matrix calculated in e
    Jdot = [- sin(q1)*d_q2 - cos(q1)*d_q1*(d2 + q2), -sin(q1)*d_q1;
              cos(q1)*d_q2 - sin(q1)*d_q1*(d2 + q2),  cos(q1)*d_q1];

    % Controllers
    Kp = [310, 0;            
          0, 310];
    Kd = [30, 0;            
          0, 30];

    % Position
    pd = c + r *[cos(w*t); sin(w*t)];

    % Transpose Jacobian Method
    N = m2*g*[q2*cos(q1); sin(q1)];
    u = transpose(J)*Kp*(pd-p)-Kd*[x(3);x(4)] + N;
    
    % Euler method
    x=x+controller_jt_f(x,u)*dt;

    % Runge-Kutta method
    %x=x+dt*(0.25*controller_jt_f(x,u)+0.75*(controller_jt_f(x+dt*(2/3)*controller_jt_f(x,u),u))); 
    
    frame_counter =frame_counter+1;
    
    % Frame sampling
    if frame_counter == 20
       %plot(t,x(1),'k--.',t,w,'r--.',t,u,'g--.') 
       controller_jt_draw(x,pd)
       pause(dt)
       frame_counter =0;
    end
end