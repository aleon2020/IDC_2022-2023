clc; clear; close all;
syms d2 q1 q2;
p1 = (q2 + d2) * cos(q1);
p2 = (q2 + d2) * sin(q1);
J = jacobian([p1, p2], [q1, q2])