init;

% Initial state
x = [-pi/3;(2*pi)/3;0;0]; 
u = [0;0];
y = [0;0];

dt=0.01;

%Parametros
l_z1 = 1;
l_z2 = 1;
m1 = 1;
m2 = 1;
l1 = 1;
l2 = 1;
r1 = l1/2;
r2 = l2/2;
c = [1;1];
r = 0.5;
g = 9.81;



frame_counter=0;

t=0;
 

for t=0:dt:100
    q1 = x(1);
    q2 = x(2);
    q1_d = x(3);
    q2_d = x(4);

    y = [l1*cos(x(1)) + l2*cos(x(1) + x(2)); l1*sin(x(1)) + l2*sin(x(1) + x(2))];
    p = y;
    J = [-l2*sin(x(1) + x(2)) - l1*sin(x(1)), -l2*sin(x(1) + x(2));
        l2*cos(x(1) + x(2)) + l1*cos(x(1)), l2*cos(x(1) + x(2))];
    Jdot = [-l1*cos(x(1))*x(3) - l2*cos(x(1) + x(2))*(x(3) + x(4)), -l2*cos(x(1) + x(2))*(x(3) + x(4));
        -l1*sin(x(1))*x(3) - l2*sin(x(1) + x(2))*(x(3) + x(4)), -l2*sin(x(1) + x(2))*(x(3) + x(4))];

    Kp = [30, 0;            %Proporcional 
          0, 30];
    Kd = [10, 0;            %D controla la velocidad 
          0, 10];

    alpha = l_z1 + l_z2 + m1*(r1)^2 + m2*((l1)^2 + (r2)^2);
    beta = m2*l1*r2;
    delta = l_z2 + m2*(r2)^2;
    
    B = [alpha + 2*beta*cos(q2), delta + beta*cos(q2);
        delta + beta*cos(q2), delta];
    
    C = [-beta*sin(q2)*q2_d, -beta*sin(q2)*(q1_d + q2_d);
        beta*sin(q2)*q1_d, 0];

    
    %Posicion deseada
    pd = c + r *[cos(t); sin(t)];
    pd_d = r*[-sin(t); cos(t)];
    pd_dd = r*[-cos(t); -sin(t)];

    %Controlador
    v = inv(J)*(pd_dd + Kd*(pd_d - J*[x(3); x(4)]) + Kp*(pd-p)-Jdot*[x(3); x(4)])
    
    %Sin gravedad
    %u = B*v + C*[x(3);x(4)];

    %Con gravedad
    N = [(m1*r1 + m2*l1)*g*cos(x(1)) + m2*r2*g*cos(x(1) + x(2));
        m2*r2*g*cos(x(1) + x(2))];
    u = B*v + C*[x(3);x(4)] + N;

    x=x+planarRR_f(x,u)*dt; % Euler
    %x=x+dt*(0.25*e_6p4_f(x,u)+0.75*(e_6p4_f(x+dt*(2/3)*e_6p4_f(x,u),u))); % Runge-Kutta
    
    frame_counter =frame_counter+1;
    
    % Frame sampling
    if frame_counter == 5 %Para separar puntos y demas
       %graph_draw(t,x,w,u); 
       arm_draw(x)
       pause(0.000001)
       frame_counter =0;
    end
end


